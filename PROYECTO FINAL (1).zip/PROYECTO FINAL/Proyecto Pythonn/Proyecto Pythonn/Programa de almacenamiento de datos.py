#PROGRAMA DE ALMACENAMIENTO DE DATOS
def almacenar_datos():
    nombre_pelicula = input("Ingrese el nombre de la película: ")
    reseña = input("Ingrese una reseña sobre la película: ")
    recomendacion = input("¿Recomienda ver la película? (si/no): ")
    calificacion = int(input("Ingrese una calificación de 1 a 5 para la película: "))

    with open("almacenamiento_peliculas.txt", "a") as archivo:
        archivo.write("Nombre de la película: " + nombre_pelicula + "\n")
        archivo.write("Reseña: " + reseña + "\n")
        archivo.write("Recomendación: " + recomendacion + "\n")
        archivo.write("Calificación: " + str(calificacion) + "\n")
        archivo.write("\n")  

    print("-------- GRACIAS POR TU RESEÑA --------")
    print("Nombre de la película:", nombre_pelicula)
    print("Reseña:", reseña)
    print("Recomendación:", recomendacion)
    print("Calificación:", calificacion)


def main():
    continuar = True
    while continuar:
        almacenar_datos()
        respuesta = input("--------¿DESEA INGRESAR UNA RESEÑA NUEVA? (SI/NO): --------")
        if respuesta.lower() != "si":
            continuar = False


if __name__ == "__main__":
    main()